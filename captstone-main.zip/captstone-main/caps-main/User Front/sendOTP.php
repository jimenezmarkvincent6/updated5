<?php
$email = $_POST['email'];
$otp = mt_rand(100000, 999999); // 6-digit OTP


include_once 'connection.php'; // Assuming connection.php uses mysqli

// Correct SQL query with a placeholder for email
$sql = "SELECT * FROM parent_acc WHERE email = ?";
$stmt = $conn->prepare($sql);

// Bind the email parameter to the prepared statement
$stmt->bind_param("s", $email); // "s" means the parameter is a string

// Execute the prepared statement
$stmt->execute();
$result = $stmt->get_result();
$count = $result->num_rows;

if ($count > 0) {
    // Correct SQL update query with a placeholder for email and OTP
    $sql_update_statement = "UPDATE parent_acc SET otp = ? WHERE email = ?";
    $statement = $conn->prepare($sql_update_statement);

    // Bind the parameters for OTP and email
    $statement->bind_param("is", $otp, $email); // "i" means the OTP is an integer, "s" means email is a string

    // Execute the update
    $statement->execute();

    try {
        require 'emailAPI.php'; // Ensure this file contains correct email configuration

        // Set valid sender email address, replace 'your_email@example.com' with the actual sender email
        $sender = 'your_email@example.com'; // Ensure this email is valid and exists on your mail server
        $mail->setFrom($sender, 'OTP Sender');
        
        // Set recipient email address
        $mail->addAddress($email, 'Syntax Flow');
        
        // Reply-to email address, ensure 'your_email@example.com' is a valid email
        $mail->addReplyTo($sender, 'OTP Sender');

        // Set email format to HTML
        $mail->isHtml(true);

        // Subject and body
        $mail->Subject = 'One Time Password - OTP';
        $mail->Body = 'Here is your One Time Password <br/><b>' . $otp . '</b>';

        // Send the email
        $mail->send();
        echo 'Your OTP has been sent. Check your mail';

        ?>

        <br/>
        <a href="enterOTP.php">Enter your OTP to reset your Password</a>

        <?php

    } catch (Exception $e) {
        // If error occurs while sending email, show the error
        echo "An error occurred. The message could not be sent: {$mail->ErrorInfo}";
    }
} else {
    echo "The email address does not exist in the database";
}
?>
