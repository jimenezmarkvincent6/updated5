<?php
// Check if OTP is passed in the URL (or use session if needed)
if (isset($_GET['otp'])) {
    $otp = $_GET['otp']; // Get the OTP from the URL parameter
} elseif (isset($_POST['otp'])) {
    $otp = $_POST['otp']; // Get the OTP from POST data (if submitted by form)
} else {
    // If OTP is not set, show an error
    echo 'OTP not provided.';
    exit; // Exit the script if OTP is not found
}

include 'connection.php'; // Include database connection

// Correct SQL query with a placeholder for the OTP
$sql = "SELECT * FROM parent_acc WHERE otp = ?";

// Prepare the statement using MySQLi
$stmt = $conn->prepare($sql);

// Bind the OTP parameter (MySQLi uses 'i' for integer)
$stmt->bind_param("i", $otp); // "i" means the parameter is an integer

// Execute the statement
$stmt->execute();

// Get the result of the query
$result = $stmt->get_result();
$count = $result->num_rows;

if ($count > 0) {
    // If OTP is found in the database, display the reset password form
    ?>
    <div class="login-container">
        <h2>Enter OTP</h2>

        <!-- Login form for new password -->
        <form method="POST" action="reset_password.php">
            <input type="hidden" name="otp" value="<?php echo $otp; ?>" /> <!-- Pass OTP back in form -->
            <div class="form-group">
                <input type="password" name="new_password" required>
                <span>New Password</span>
            </div>
            <div class="form-group">
                <input type="password" name="confirm_password" required>
                <span>Confirm Password</span>
            </div>
            <button type="submit" class="btn">Submit</button>
        </form>
    </div>

    <?php
    // Handle password reset after form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Check if 'new_password' and 'confirm_password' exist in the POST data
        if (isset($_POST['new_password']) && isset($_POST['confirm_password'])) {
            // Get the new password and confirm password from POST data
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];

            // Check if both passwords match
            if ($new_password === $confirm_password) {
                // Hash the new password
                $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

                // Get the user's email or ID from the session or the OTP query (assuming email is available in result)
                $user = $result->fetch_assoc();
                $email = $user['email'];

                // Update the password in the database
                $update_sql = "UPDATE parent_acc SET password = ? WHERE email = ?";
                $update_stmt = $conn->prepare($update_sql);

                // Bind the parameters
                $update_stmt->bind_param("ss", $hashed_password, $email); // "ss" means both are strings

                // Execute the update
                if ($update_stmt->execute()) {
                    // Redirect to login page after successful password update
                    header("Location: login.php");
                    exit(); // Make sure to exit after the header redirection
                } else {
                    echo 'There was an error updating your password. Please try again.';
                }
            } else {
                // If the passwords don't match
                echo 'The passwords do not match. Please try again.';
            }
        }
    }

} else {
    // If the OTP is incorrect or not found
    echo 'Incorrect OTP. Try Again...';
}
?>
