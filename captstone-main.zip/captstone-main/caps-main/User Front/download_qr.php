<?php
require 'connection.php';
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die('Error: User is not logged in.');
}

// Get the logged-in user's ID
$parent_id = intval($_SESSION['user_id']);

// Optionally filter by child_id
$child_id = isset($_GET['child_id']) ? intval($_GET['child_id']) : null;

try {
    if ($child_id) {
        $stmt = $pdo->prepare('SELECT qrimage FROM child_acc WHERE parent_id = ? AND id = ?');
        $stmt->execute([$parent_id, $child_id]);
    } else {
        $stmt = $pdo->prepare('SELECT qrimage FROM child_acc WHERE parent_id = ?');
        $stmt->execute([$parent_id]);
    }

    $children = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$children) {
        die('Error: No QR codes found.');
    }

    foreach ($children as $child) {
        if (!empty($child['qrimage'])) {
            echo '<img src="data:image/png;base64,' . base64_encode($child['qrimage']) . '" alt="QR Code" />';
        } else {
            echo '<p>No QR code available for this child.</p>';
        }
    }
} catch (PDOException $e) {
    die('Database error: ' . $e->getMessage());
}
?>
