<?php
// delete_staff.php
session_start();
include 'connection.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Super Admin') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized access'
    ]);
    exit;
}

// Get the JSON data from the request
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!isset($data['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Staff ID is required'
    ]);
    exit;
}

$staffId = $data['id'];

try {
    // Begin transaction
    $conn->begin_transaction();

    // Prepare the delete statement
    $stmt = $conn->prepare("DELETE FROM admin_staff WHERE id = ?");
    $stmt->bind_param("i", $staffId);

    // Execute the delete
    if ($stmt->execute()) {
        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Staff member deleted successfully'
        ]);
    } else {
        throw new Exception("Error executing delete query");
    }
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    
    echo json_encode([
        'success' => false,
        'message' => 'Failed to delete staff member: ' . $e->getMessage()
    ]);
} finally {
    $stmt->close();
    $conn->close();
}
?>