<?php
session_start();
include 'connection.php';

// Check if user is logged in and has Super Admin role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Super Admin') {
    $response = array('success' => false, 'message' => 'Unauthorized access');
    echo json_encode($response);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['parent_id'])) {
    $parent_id = $_POST['parent_id'];
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // First, check if the parent record exists
        $check_stmt = $conn->prepare("SELECT id FROM parent_acc WHERE id = ?");
        $check_stmt->bind_param("i", $parent_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception("Parent record not found");
        }
        
        // Delete from child_acc table first (if exists)
        $stmt = $conn->prepare("DELETE FROM child_acc WHERE parent_id = ?");
        $stmt->bind_param("i", $parent_id);
        $stmt->execute();
        
        // Delete from authorized_persons table (if exists)
        $stmt = $conn->prepare("DELETE FROM authorized_persons WHERE parent_id = ?");
        $stmt->bind_param("i", $parent_id);
        $stmt->execute();
        
        // Finally delete the parent record
        $stmt = $conn->prepare("DELETE FROM parent_acc WHERE id = ?");
        $stmt->bind_param("i", $parent_id);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            // If all queries successful, commit transaction
            $conn->commit();
            $response = array('success' => true, 'message' => 'Parent record and related records deleted successfully');
        } else {
            throw new Exception("Failed to delete parent record");
        }
        
    } catch (Exception $e) {
        // If any query fails, rollback all changes
        $conn->rollback();
        $response = array('success' => false, 'message' => 'Error deleting record: ' . $e->getMessage());
    }
    
    echo json_encode($response);
    
    // Close all statements
    if (isset($check_stmt)) $check_stmt->close();
    if (isset($stmt)) $stmt->close();
    $conn->close();
    
} else {
    $response = array('success' => false, 'message' => 'Invalid request');
    echo json_encode($response);
}
?>