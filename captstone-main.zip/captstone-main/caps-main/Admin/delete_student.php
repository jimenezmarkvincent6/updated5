<?php
session_start();
include 'connection.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set header to return JSON response
header('Content-Type: application/json');

// Log function
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . "\n", 3, 'delete_error.log');
}

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Super Admin') {
    echo json_encode([
        'success' => false, 
        'message' => 'Unauthorized access'
    ]);
    exit();
}

if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'No student ID provided'
    ]);
    exit();
}

$student_id = intval($_POST['id']);

// Start transaction
$conn->begin_transaction();

try {
    // First, check if the student exists
    $check_stmt = $conn->prepare("SELECT id, parent_id, authorized_id FROM child_acc WHERE id = ?");
    $check_stmt->bind_param("i", $student_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("Student record not found");
    }

    // Delete the student record from child_acc
    $stmt = $conn->prepare("DELETE FROM child_acc WHERE id = ?");
    if (!$stmt) {
        throw new Exception("Prepare failed for deletion: " . $conn->error);
    }
    
    $stmt->bind_param("i", $student_id);
    
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }
    
    if ($stmt->affected_rows === 0) {
        throw new Exception("No record was deleted");
    }
    
    $stmt->close();
    
    // If we get here, commit the transaction
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Student record deleted successfully'
    ]);

} catch (Exception $e) {
    // Roll back the transaction
    $conn->rollback();
    
    // Log the error
    logError("Delete failed for student ID $student_id: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => 'Error deleting student record: ' . $e->getMessage()
    ]);
}

$conn->close();
?>