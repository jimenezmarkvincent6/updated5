<?php
$host="smtp.gmail.com";
$username="panget12222@gmail.com";
$sender="panget12222@gmail.com";
$hostPassword="ehkn drvx tdnb wpfc";

?>