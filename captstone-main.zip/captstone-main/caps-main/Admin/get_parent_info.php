<?php
include 'connection.php';

// Set the correct header for JSON response
header('Content-Type: application/json');

if (isset($_GET['child_id'])) {
    $childId = intval($_GET['child_id']); // Sanitize the input
    
    // Step 1: Fetch parent_id using child_id
    $childSql = "SELECT parent_id FROM child_acc WHERE id = ?";
    $stmt = $conn->prepare($childSql);
    $stmt->bind_param("i", $childId);
    $stmt->execute();
    $childResult = $stmt->get_result()->fetch_assoc();
    
    if (!$childResult) {
        echo json_encode(['success' => false, 'message' => 'Child ID not associated with any parent.']);
        exit;
    }
    
    $parentId = $childResult['parent_id'];

    // Step 2: Fetch parent info
    $parentSql = "SELECT fullname, address, parent_image FROM parent_acc WHERE id = ?";
    $stmt = $conn->prepare($parentSql);
    $stmt->bind_param("i", $parentId);
    $stmt->execute();
    $parentResult = $stmt->get_result()->fetch_assoc();
    
    if (!$parentResult) {
        echo json_encode(['success' => false, 'message' => 'Parent not found in parent_acc table.']);
        exit;
    }
    
    // Handle parent image
    if (!empty($parentResult['parent_image'])) {
        $parentResult['parent_image'] = 'data:image/jpeg;base64,' . base64_encode($parentResult['parent_image']);
    } else {
        $parentResult['parent_image'] = '/placeholder.svg';
    }

    // Step 3: Fetch authorized persons
    $authSql = "SELECT fullname, authorized_image FROM authorized_persons WHERE parent_id = ?";
    $stmt = $conn->prepare($authSql);
    $stmt->bind_param("i", $parentId);
    $stmt->execute();
    $authResult = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    foreach ($authResult as &$person) {
        if (!empty($person['authorized_image'])) {
            $person['authorized_image'] = 'data:image/jpeg;base64,' . base64_encode($person['authorized_image']);
        } else {
            $person['authorized_image'] = '/placeholder.svg';
        }
    }

    // Final response
    echo json_encode([
        'success' => true,
        'parent' => $parentResult,
        'authorizedPersons' => $authResult
    ]);

} else {
    echo json_encode(['success' => false, 'message' => 'No child ID provided.']);
}

$conn->close();
?>
