<?php
// delete_staff.php
session_start();
include 'connection.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Super Admin') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized access'
    ]);
    exit;
}

// Check if ID was sent via POST
if (!isset($_POST['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Staff ID is required'
    ]);
    exit;
}

$staffId = $_POST['id'];

try {
    // Begin transaction
    $conn->begin_transaction();

    // Prepare the delete statement
    $stmt = $conn->prepare("DELETE FROM admin_staff WHERE id = ?");
    $stmt->bind_param("i", $staffId);

    // Execute the delete
    if ($stmt->execute()) {
        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Staff member deleted successfully'
        ]);
    } else {
        throw new Exception("Error executing delete query");
    }
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    
    echo json_encode([
        'success' => false,
        'message' => 'Failed to delete staff member: ' . $e->getMessage()
    ]);
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}
?>