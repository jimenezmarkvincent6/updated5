<?php

use PHPMailer\PHPMailer\PhpMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require './setting.php';


$mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host     = $host;
    $mail->SMTPAuth = true;
    $mail->Username = $username;
    $mail->Password = $hostPassword;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->port       = 587;


?>